CREATE VIEW view_articles AS
  SELECT
    `technews`.`article`.`IDARTICLE`            AS `IDARTICLE`,
    `technews`.`article`.`IDAUTEUR`             AS `IDAUTEUR`,
    `technews`.`article`.`IDCATEGORIE`          AS `IDCATEGORIE`,
    `technews`.`categorie`.`LIBELLECATEGORIE`   AS `LIBELLECATEGORIE`,
    `technews`.`article`.`TITREARTICLE`         AS `TITREARTICLE`,
    `technews`.`article`.`CONTENUARTICLE`       AS `CONTENUARTICLE`,
    `technews`.`article`.`FEATUREDIMAGEARTICLE` AS `FEATUREDIMAGEARTICLE`,
    `technews`.`article`.`SPECIALARTICLE`       AS `SPECIALARTICLE`,
    `technews`.`article`.`SPOTLIGHTARTICLE`     AS `SPOTLIGHTARTICLE`,
    `technews`.`article`.`DATECREATIONARTICLE`  AS `DATECREATIONARTICLE`,
    `technews`.`auteur`.`NOMAUTEUR`             AS `NOMAUTEUR`,
    `technews`.`auteur`.`PRENOMAUTEUR`          AS `PRENOMAUTEUR`,
    `technews`.`auteur`.`EMAILAUTEUR`           AS `EMAILAUTEUR`
  FROM ((`technews`.`article`
    JOIN `technews`.`auteur`) JOIN `technews`.`categorie`)
  WHERE ((`technews`.`article`.`IDAUTEUR` = `technews`.`auteur`.`IDAUTEUR`) AND
         (`technews`.`article`.`IDCATEGORIE` = `technews`.`categorie`.`IDCATEGORIE`));

